rm -f firewall_configured && python config-fw-v2.py $3
ansible-playbook create_nat.yml --extra-vars "username=$1 password=$2 ip_address=$3 destination_ip_1=$4 destination_ip_2=$5"
